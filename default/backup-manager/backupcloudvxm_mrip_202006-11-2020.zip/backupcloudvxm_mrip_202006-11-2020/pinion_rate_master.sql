 DROP TABLE IF EXISTS `pinion_rate_master`;

CREATE TABLE `pinion_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `cItemType` varchar(30) NOT NULL,
  `iDMValue` int(11) NOT NULL,
  `cType` varchar(20) NOT NULL,
  `fFaceFrom` float(10,2) NOT NULL,
  `fFaceTo` float(10,2) NOT NULL,
  `cFaceType` varchar(20) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

