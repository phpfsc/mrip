 DROP TABLE IF EXISTS `special_item_rate_master`;

CREATE TABLE `special_item_rate_master` (
  `iPartyID` int(11) NOT NULL,
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `cItemName` varchar(200) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  `cMeasurement` varchar(20) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO special_item_rate_master VALUES('1', '1', '8 mod face 5 L.H.S', '7.50', 'PT');INSERT INTO special_item_rate_master VALUES('1', '2', '8 MOD face 6 L.H.S', '8.00', 'PT');