 DROP TABLE IF EXISTS `party_order`;

CREATE TABLE `party_order` (
  `iOrderID` int(11) NOT NULL AUTO_INCREMENT,
  `cOrderCode` varchar(100) NOT NULL,
  `dOrderDate` date NOT NULL,
  `iPartyCode` int(11) NOT NULL,
  `cChallanNo` varchar(200) DEFAULT NULL,
  `fMinValue` float(10,2) NOT NULL DEFAULT '60.00',
  `cRemarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`iOrderID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO party_order VALUES('1', 'OD/29/10/20-21/000001', '2020-10-29', '142', '111', '100.00', '');INSERT INTO party_order VALUES('3', 'OD/03/11/20-21/000002', '2020-11-03', '101', '', '100.00', '');