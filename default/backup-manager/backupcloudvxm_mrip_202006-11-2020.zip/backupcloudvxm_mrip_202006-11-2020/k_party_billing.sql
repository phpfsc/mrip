 DROP TABLE IF EXISTS `k_party_billing`;

CREATE TABLE `k_party_billing` (
  `iBillingID` int(11) NOT NULL AUTO_INCREMENT,
  `cBillingCode` varchar(100) NOT NULL,
  `dBillingDate` date NOT NULL,
  `dToDate` date NOT NULL,
  `iCompanyCode` int(11) NOT NULL,
  `iCompanySNo` int(11) NOT NULL,
  `iPartyCode` int(11) NOT NULL,
  `iFirmSNo` int(11) NOT NULL,
  `fBillTotal` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Total Bill Value Without Tax Calculation ( Items Total Amount) Needs to be updated every time Bill is Changed',
  `iBillingType` int(11) NOT NULL DEFAULT '0' COMMENT '0 - Billing Against Order 1- Billing Without Order ',
  `fBillAmt` float(10,2) NOT NULL,
  `cRemarks` varchar(200) DEFAULT NULL,
  `bDeleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`iBillingID`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO k_party_billing VALUES('21', 'PTW/23/10/20-21/001430', '2020-10-23', '0000-00-00', '1', '0', '133', '0', '36.00', '0', '36.00', 'testing', '0');INSERT INTO k_party_billing VALUES('22', 'PTW/29/10/20-21/001431', '2020-10-29', '2020-10-29', '1', '0', '174', '0', '18000.00', '1', '18000.00', '', '0');INSERT INTO k_party_billing VALUES('23', 'PTW/29/10/20-21/001432', '2020-10-29', '2020-10-29', '1', '0', '174', '0', '18000.00', '1', '18000.00', '', '0');INSERT INTO k_party_billing VALUES('24', 'PTW/29/10/20-21/001433', '2020-10-29', '2020-10-29', '1', '0', '174', '0', '18000.00', '1', '18000.00', '', '0');INSERT INTO k_party_billing VALUES('25', 'PTW/29/10/20-21/001434', '2020-10-29', '2020-10-29', '1', '0', '174', '0', '18000.00', '1', '18000.00', '', '0');INSERT INTO k_party_billing VALUES('26', 'PTW/29/10/20-21/001435', '2020-10-29', '2020-10-29', '1', '0', '142', '0', '13600.00', '1', '13600.00', 'testing for kacha bill', '0');INSERT INTO k_party_billing VALUES('27', 'PTW/29/10/20-21/001436', '2020-10-29', '0000-00-00', '1', '0', '142', '0', '2400.00', '0', '2400.00', 'kacha bill with order', '1');