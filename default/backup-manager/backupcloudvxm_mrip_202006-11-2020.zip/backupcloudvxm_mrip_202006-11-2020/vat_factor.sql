 DROP TABLE IF EXISTS `vat_factor`;

CREATE TABLE `vat_factor` (
  `fVatFactor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO vat_factor VALUES('50');