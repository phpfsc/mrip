 DROP TABLE IF EXISTS `category_master`;

CREATE TABLE `category_master` (
  `cCategoryCode` varchar(20) NOT NULL,
  `cCategoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

