 DROP TABLE IF EXISTS `party_billing_detail`;

CREATE TABLE `party_billing_detail` (
  `iBillingID` int(11) NOT NULL,
  `iOrderID` int(11) NOT NULL,
  `cItemType` varchar(50) NOT NULL,
  `iItemCode` int(11) NOT NULL,
  `cMiscItemName` varchar(200) DEFAULT NULL COMMENT 'If Misc Item is There Regular Item Code Will Contain Zero (0) Other wise as per Item , Item Type Would be Misc and  Part Type Would also be Misc',
  `fRate` float(10,2) NOT NULL,
  `iNoPcsDisp` int(11) NOT NULL,
  `cPartType` varchar(20) NOT NULL,
  `cPcs` varchar(5) DEFAULT NULL,
  `cCollar` varchar(100) DEFAULT NULL,
  `cItemRemarks` varchar(200) DEFAULT NULL,
  `fMinValue` float(10,2) NOT NULL DEFAULT '60.00',
  `cYearPrefix` varchar(20) NOT NULL DEFAULT '',
  KEY `iBillingID` (`iBillingID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO party_billing_detail VALUES('1', '0', 'BURADA', '0', 'remarks', '23.00', '2', 'BURADA', '', '', '', '0.00', '');INSERT INTO party_billing_detail VALUES('2', '3', 'Gear', '2981', '', '20.00', '2', 'PowerPress', 'PT', '', '', '100.00', '');