 DROP TABLE IF EXISTS `company_master`;

CREATE TABLE `company_master` (
  `iPartyID` int(11) NOT NULL AUTO_INCREMENT,
  `cPartyName` varchar(200) NOT NULL,
  `cContactPerson` varchar(200) NOT NULL,
  `cAddress` varchar(250) NOT NULL,
  `cPhone` varchar(100) DEFAULT NULL,
  `cMobile` varchar(50) DEFAULT NULL,
  `cFax` varchar(50) DEFAULT NULL,
  `cSTNo` varchar(50) DEFAULT NULL,
  `cCSTNo` varchar(50) DEFAULT NULL,
  `cTINNo` varchar(50) NOT NULL,
  `cGSTIn` varchar(15) NOT NULL,
  `cHSNCode` varchar(50) NOT NULL,
  `iInvoiceSerial` int(11) NOT NULL,
  `cInvoiceCode` varchar(50) NOT NULL,
  `cTransporter` varchar(200) DEFAULT NULL,
  `cRemarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`iPartyID`),
  UNIQUE KEY `cPartyName` (`cPartyName`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_master VALUES('1', 'PARKASH TECHNICAL WORKS ', 'MR. PUNEET GOYAL', 'Old Oswal Street, GT Road Miller Ganj LUDHIANA', '2531045', '9872227755', '0161-4624121', '45917015 Dt 16-05-88', '45917015 Dt  11-04-91', '03561114081', '03AGQPG7432A1ZT', '9988', '1430', 'PTW', 'NONE', 'NONE');