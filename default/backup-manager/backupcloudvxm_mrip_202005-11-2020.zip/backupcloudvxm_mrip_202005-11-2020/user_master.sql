 DROP TABLE IF EXISTS `user_master`;

CREATE TABLE `user_master` (
  `cUserId` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `cLoginName` varchar(50) NOT NULL,
  `cPassword` varchar(50) NOT NULL,
  `bActive` tinyint(1) DEFAULT '1',
  `bBilling` tinyint(4) DEFAULT '1' COMMENT '1 is for Pakka Billing and 0 for Kacha Billing',
  `userImage` varchar(255) NOT NULL,
  PRIMARY KEY (`cUserId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO user_master VALUES('1', 'Puneet', 'Goyal', 'AYAAN', 'WVhsaFlXND0=', '1', '1', '../uploads/1/default-non-user-no-photo-1.jpg');INSERT INTO user_master VALUES('2', 'akash', 'Singh', 'BILLING', 'WVhsaFlXND0=', '1', '2', '');