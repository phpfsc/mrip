 DROP TABLE IF EXISTS `chain_gear_rate_master`;

CREATE TABLE `chain_gear_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `fPitchValue` float(10,2) NOT NULL,
  `cPitchType` varchar(20) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO chain_gear_rate_master VALUES('1', '0.62', 'inches', '2.00');INSERT INTO chain_gear_rate_master VALUES('2', '0.75', 'inches', '2.00');INSERT INTO chain_gear_rate_master VALUES('3', '1.00', 'inches', '2.00');INSERT INTO chain_gear_rate_master VALUES('4', '1.25', 'inches', '3.00');INSERT INTO chain_gear_rate_master VALUES('5', '1.50', 'inches', '8.00');INSERT INTO chain_gear_rate_master VALUES('6', '2.00', 'inches', '12.00');INSERT INTO chain_gear_rate_master VALUES('7', '32.00', 'mm', '15.00');