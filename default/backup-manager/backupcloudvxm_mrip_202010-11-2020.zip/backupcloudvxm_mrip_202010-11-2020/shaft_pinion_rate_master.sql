 DROP TABLE IF EXISTS `shaft_pinion_rate_master`;

CREATE TABLE `shaft_pinion_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `cItemType` varchar(20) NOT NULL,
  `fDMValue` float(10,2) NOT NULL,
  `cType` varchar(20) NOT NULL,
  `fFaceFrom` float(10,2) NOT NULL,
  `fFaceTo` float(10,2) NOT NULL,
  `cFaceType` varchar(20) NOT NULL,
  `iTeeth` int(11) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO shaft_pinion_rate_master VALUES('1', 'Plain', '3.00', 'DP', '0.00', '5.00', 'inches', '13', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('2', 'Plain', '3.00', 'DP', '0.00', '4.00', 'inches', '14', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('3', 'Plain', '3.00', 'DP', '0.00', '5.00', 'inches', '15', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('4', 'Plain', '3.50', 'DP', '0.00', '5.00', 'inches', '15', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('5', 'Plain', '3.00', 'DP', '0.00', '4.00', 'inches', '10', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('6', 'Plain', '4.00', 'DP', '0.00', '4.00', 'inches', '13', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('7', 'Plain', '4.00', 'DP', '0.00', '4.00', 'inches', '14', '50.00');INSERT INTO shaft_pinion_rate_master VALUES('8', 'Plain', '2.50', 'DP', '0.00', '5.00', 'inches', '12', '60.00');INSERT INTO shaft_pinion_rate_master VALUES('9', 'Plain', '2.50', 'DP', '5.10', '6.00', 'inches', '12', '75.00');INSERT INTO shaft_pinion_rate_master VALUES('10', 'Plain', '2.50', 'DP', '0.00', '6.00', 'inches', '15', '90.00');INSERT INTO shaft_pinion_rate_master VALUES('11', 'Helical', '3.00', 'DP', '0.00', '5.00', 'inches', '0', '18.00');INSERT INTO shaft_pinion_rate_master VALUES('12', 'Helical', '7.00', 'Module', '0.00', '5.00', 'inches', '0', '18.00');