 DROP TABLE IF EXISTS `bevel_gear_rate_master`;

CREATE TABLE `bevel_gear_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `fDMValue` float(10,2) NOT NULL,
  `cType` varchar(20) NOT NULL,
  `iTeeth` int(11) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO bevel_gear_rate_master VALUES('1', '3.00', 'DP', '52', '3.25');INSERT INTO bevel_gear_rate_master VALUES('2', '4.00', 'DP', '73', '3.25');INSERT INTO bevel_gear_rate_master VALUES('3', '4.00', 'DP', '38', '2.75');INSERT INTO bevel_gear_rate_master VALUES('4', '2.50', 'DP', '42', '5.00');INSERT INTO bevel_gear_rate_master VALUES('5', '8.00', 'Module', '54', '3.50');INSERT INTO bevel_gear_rate_master VALUES('6', '6.00', 'Module', '76', '3.50');INSERT INTO bevel_gear_rate_master VALUES('7', '2.50', 'DP', '15', '5.00');INSERT INTO bevel_gear_rate_master VALUES('8', '3.00', 'DP', '18', '3.25');INSERT INTO bevel_gear_rate_master VALUES('9', '4.00', 'DP', '18', '3.25');INSERT INTO bevel_gear_rate_master VALUES('10', '4.00', 'DP', '16', '2.75');INSERT INTO bevel_gear_rate_master VALUES('11', '6.00', 'Module', '22', '3.50');INSERT INTO bevel_gear_rate_master VALUES('12', '8.00', 'Module', '17', '3.50');INSERT INTO bevel_gear_rate_master VALUES('13', '3.00', 'DP', '44', '3.25');INSERT INTO bevel_gear_rate_master VALUES('14', '10.00', 'Module', '42', '5.50');INSERT INTO bevel_gear_rate_master VALUES('15', '10.00', 'Module', '15', '5.50');