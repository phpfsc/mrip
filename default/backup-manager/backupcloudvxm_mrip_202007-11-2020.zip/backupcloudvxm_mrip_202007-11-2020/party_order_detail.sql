 DROP TABLE IF EXISTS `party_order_detail`;

CREATE TABLE `party_order_detail` (
  `iOrderID` int(11) NOT NULL,
  `cItemType` varchar(50) NOT NULL COMMENT 'Gear/Pinion/Shaft Pinion/ Bevel Gear/ Bevel Pinion etc',
  `iItemCode` int(11) NOT NULL,
  `fRate` float(10,2) NOT NULL DEFAULT '0.00',
  `iNoPcsRec` int(11) NOT NULL DEFAULT '0',
  `iNoPcsDisp` int(11) NOT NULL DEFAULT '0',
  `cItemRemarks` varchar(200) DEFAULT NULL,
  `bDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `cPartType` varchar(20) NOT NULL COMMENT 'Power Press Item or Expeller Part Item',
  `cPcs` varchar(5) NOT NULL COMMENT 'Rate calculation is Per Piece (PCS) or Per Teeth (PT)',
  `cCollar` varchar(100) DEFAULT NULL COMMENT 'Used Only in Case of Pinion',
  KEY `iOrderID` (`iOrderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO party_order_detail VALUES('1', 'Gear', '1504', '6.00', '4', '3', '', '0', 'Expeller', 'PT', '');INSERT INTO party_order_detail VALUES('1', 'Gear', '2685', '3.00', '6', '2', '', '0', 'Expeller', 'PT', '');INSERT INTO party_order_detail VALUES('3', 'Gear', '2981', '20.00', '10', '2', 'remarks', '0', 'PowerPress', 'PT', '');