 DROP TABLE IF EXISTS `pp_gear_rate_master`;

CREATE TABLE `pp_gear_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `fDMValue` float(10,2) NOT NULL,
  `cType` varchar(20) NOT NULL,
  `fDiaFrom` float(10,3) NOT NULL,
  `fDiaTo` float(10,3) NOT NULL,
  `cDiaType` varchar(20) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO pp_gear_rate_master VALUES('1', '3.00', 'DP', '0.000', '30.000', 'inches', '10.00');INSERT INTO pp_gear_rate_master VALUES('2', '3.00', 'DP', '30.100', '34.000', 'inches', '12.00');INSERT INTO pp_gear_rate_master VALUES('3', '3.00', 'DP', '34.100', '40.000', 'inches', '12.00');INSERT INTO pp_gear_rate_master VALUES('4', '3.00', 'DP', '40.100', '48.000', 'inches', '15.00');INSERT INTO pp_gear_rate_master VALUES('5', '4.00', 'DP', '0.000', '24.000', 'inches', '6.00');INSERT INTO pp_gear_rate_master VALUES('6', '4.00', 'DP', '24.100', '26.000', 'inches', '6.00');INSERT INTO pp_gear_rate_master VALUES('7', '4.00', 'DP', '26.100', '30.000', 'inches', '8.00');INSERT INTO pp_gear_rate_master VALUES('8', '5.00', 'DP', '0.000', '21.000', 'inches', '4.00');INSERT INTO pp_gear_rate_master VALUES('9', '5.00', 'DP', '21.100', '23.000', 'inches', '4.00');INSERT INTO pp_gear_rate_master VALUES('10', '6.00', 'DP', '0.000', '21.000', 'inches', '3.50');INSERT INTO pp_gear_rate_master VALUES('11', '2.50', 'DP', '0.000', '48.000', 'inches', '35.00');INSERT INTO pp_gear_rate_master VALUES('12', '2.50', 'DP', '48.100', '52.000', 'inches', '40.00');INSERT INTO pp_gear_rate_master VALUES('13', '2.50', 'DP', '52.100', '56.000', 'inches', '45.00');