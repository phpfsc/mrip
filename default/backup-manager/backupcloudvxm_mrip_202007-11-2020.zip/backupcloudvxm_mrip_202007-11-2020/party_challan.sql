 DROP TABLE IF EXISTS `party_challan`;

CREATE TABLE `party_challan` (
  `iChallanID` int(11) NOT NULL AUTO_INCREMENT,
  `cChallanCode` varchar(100) NOT NULL,
  `dChallanDate` date NOT NULL,
  `iPartyCode` int(11) NOT NULL,
  `cChallanNo` varchar(200) NOT NULL,
  `cRemarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`iChallanID`),
  KEY `iChallanID` (`iChallanID`),
  KEY `cChallanCode` (`cChallanCode`),
  KEY `iPartyCode` (`iPartyCode`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO party_challan VALUES('1', 'DC/26/10/20-21/000001', '2020-10-26', '101', '123', '');INSERT INTO party_challan VALUES('5', 'DC/29/10/20-21/000002', '2020-10-29', '142', '111', '');INSERT INTO party_challan VALUES('6', 'DC/29/10/20-21/000003', '2020-10-29', '142', '111', '');INSERT INTO party_challan VALUES('7', 'DC/29/10/20-21/000004', '2020-10-29', '142', '111', '');INSERT INTO party_challan VALUES('8', 'DC/03/11/20-21/000005', '2020-11-03', '101', '111', '');