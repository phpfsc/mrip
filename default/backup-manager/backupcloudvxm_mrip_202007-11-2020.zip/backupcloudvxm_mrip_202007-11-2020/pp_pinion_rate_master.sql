 DROP TABLE IF EXISTS `pp_pinion_rate_master`;

CREATE TABLE `pp_pinion_rate_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `fDMValue` float(10,2) NOT NULL,
  `cType` varchar(20) NOT NULL,
  `iTeethFrom` int(11) NOT NULL,
  `iTeethTo` int(11) NOT NULL,
  `fRate` float(10,2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO pp_pinion_rate_master VALUES('1', '3.00', 'DP', '1', '17', '10.00');INSERT INTO pp_pinion_rate_master VALUES('2', '3.00', 'DP', '18', '21', '12.00');INSERT INTO pp_pinion_rate_master VALUES('3', '3.00', 'DP', '22', '26', '15.00');INSERT INTO pp_pinion_rate_master VALUES('4', '4.00', 'DP', '1', '21', '6.00');INSERT INTO pp_pinion_rate_master VALUES('5', '5.00', 'DP', '1', '25', '6.00');INSERT INTO pp_pinion_rate_master VALUES('6', '6.00', 'DP', '1', '25', '6.00');INSERT INTO pp_pinion_rate_master VALUES('7', '2.50', 'DP', '1', '21', '35.00');INSERT INTO pp_pinion_rate_master VALUES('8', '2.50', 'DP', '22', '26', '40.00');