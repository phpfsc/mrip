 DROP TABLE IF EXISTS `k_party_billing_detail`;

CREATE TABLE `k_party_billing_detail` (
  `iBillingID` int(11) NOT NULL,
  `iOrderID` int(11) NOT NULL,
  `cItemType` varchar(50) NOT NULL,
  `iItemCode` int(11) NOT NULL,
  `cMiscItemName` varchar(200) DEFAULT NULL COMMENT 'If Misc Item is There Regular Item Code Will Contain Zero (0) Other wise as per Item , Item Type Would be Misc and  Part Type Would also be Misc',
  `fRate` float(10,2) NOT NULL,
  `iNoPcsDisp` int(11) NOT NULL,
  `cPartType` varchar(20) NOT NULL,
  `cPcs` varchar(5) DEFAULT NULL,
  `cCollar` varchar(100) DEFAULT NULL,
  `cItemRemarks` varchar(200) DEFAULT NULL,
  `fMinValue` float(10,2) NOT NULL DEFAULT '60.00',
  `cYearPrefix` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO k_party_billing_detail VALUES('21', '345', 'Gear', '2981', '', '12.00', '1', 'Expeller', 'PT', '', '', '100.00', '');INSERT INTO k_party_billing_detail VALUES('22', '0', 'Gear', '3620', '', '300.00', '10', 'Expeller', 'PT', '', '', '0.00', '');INSERT INTO k_party_billing_detail VALUES('23', '0', 'Gear', '3620', '', '300.00', '10', 'Expeller', 'PT', '', '', '0.00', '');INSERT INTO k_party_billing_detail VALUES('24', '0', 'Gear', '3620', '', '300.00', '10', 'Expeller', 'PT', '', '', '0.00', '');INSERT INTO k_party_billing_detail VALUES('25', '0', 'Gear', '3620', '', '300.00', '10', 'Expeller', 'PT', '', '', '100.00', '');INSERT INTO k_party_billing_detail VALUES('26', '0', 'Bevel Gear', '88', '', '100.00', '8', 'Expeller', 'PT', '', '', '100.00', '');INSERT INTO k_party_billing_detail VALUES('27', '1', 'Gear', '1504', '', '200.00', '1', 'Expeller', 'PT', '', '', '100.00', '');