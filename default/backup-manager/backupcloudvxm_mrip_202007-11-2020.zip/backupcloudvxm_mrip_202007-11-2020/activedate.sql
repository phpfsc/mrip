 DROP TABLE IF EXISTS `activedate`;

CREATE TABLE `activedate` (
  `sysDate` date NOT NULL,
  `test` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`test`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO activedate VALUES('2020-10-07', '2');