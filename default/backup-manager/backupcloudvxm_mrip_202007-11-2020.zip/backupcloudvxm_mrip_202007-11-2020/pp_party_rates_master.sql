 DROP TABLE IF EXISTS `pp_party_rates_master`;

CREATE TABLE `pp_party_rates_master` (
  `iId` int(11) NOT NULL AUTO_INCREMENT,
  `iPartyID` int(11) NOT NULL,
  `cItemName` varchar(50) NOT NULL,
  `fDMValue` float(10,2) DEFAULT NULL,
  `cType` varchar(20) DEFAULT NULL,
  `fDiaFrom` float(10,3) DEFAULT NULL,
  `fDiaTo` float(10,3) DEFAULT NULL,
  `cDiaType` varchar(20) DEFAULT NULL,
  `iTeethFrom` int(11) DEFAULT NULL,
  `iTeethTo` int(11) DEFAULT NULL,
  `cTeethType` varchar(20) DEFAULT NULL,
  `fRate` float(10,2) DEFAULT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO pp_party_rates_master VALUES('1', '66', 'Gear', '3.00', 'DP', '1.000', '34.000', 'inches', '', '', '', '6.25');INSERT INTO pp_party_rates_master VALUES('2', '66', 'Gear', '3.00', 'DP', '34.125', '40.000', 'inches', '', '', '', '8.00');INSERT INTO pp_party_rates_master VALUES('3', '66', 'Gear', '3.00', 'DP', '40.125', '48.000', 'inches', '', '', '', '10.00');INSERT INTO pp_party_rates_master VALUES('4', '66', 'Gear', '4.00', 'DP', '1.000', '26.000', 'inches', '', '', '', '4.50');INSERT INTO pp_party_rates_master VALUES('5', '66', 'Pinion', '3.00', 'DP', '', '', '', '1', '18', 'inches', '6.25');INSERT INTO pp_party_rates_master VALUES('6', '66', 'Pinion', '3.00', 'DP', '', '', '', '19', '23', 'inches', '8.00');INSERT INTO pp_party_rates_master VALUES('7', '66', 'Pinion', '4.00', 'DP', '', '', '', '1', '19', 'inches', '4.50');