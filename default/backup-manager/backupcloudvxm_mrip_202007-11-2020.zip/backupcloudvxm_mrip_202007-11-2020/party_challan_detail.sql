 DROP TABLE IF EXISTS `party_challan_detail`;

CREATE TABLE `party_challan_detail` (
  `iChallanID` int(11) NOT NULL,
  `iOrderID` int(11) NOT NULL,
  `cItemType` varchar(50) NOT NULL,
  `iItemCode` int(11) NOT NULL,
  `fRate` float(10,2) NOT NULL DEFAULT '0.00',
  `iNoPcsDisp` int(11) NOT NULL DEFAULT '0',
  `iNoPcsReturn` int(11) NOT NULL DEFAULT '0',
  `cItemRemarks` varchar(200) DEFAULT NULL,
  `cPartType` varchar(20) NOT NULL,
  `cPcs` varchar(5) NOT NULL,
  `cCollar` varchar(100) DEFAULT NULL,
  `cYearPrefix` varchar(20) NOT NULL DEFAULT '',
  KEY `iOrderID` (`iOrderID`),
  KEY `iChallanID` (`iChallanID`),
  KEY `iChallanID_2` (`iChallanID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO party_challan_detail VALUES('1', '352', 'Gear', '1506', '6.00', '1', '0', '', 'PowerPress', 'PT', '', '');INSERT INTO party_challan_detail VALUES('5', '1', 'Gear', '1504', '6.00', '1', '0', '', 'Expeller', 'PT', '', '');INSERT INTO party_challan_detail VALUES('5', '1', 'Gear', '2685', '3.00', '1', '0', '', 'Expeller', 'PT', '', '');INSERT INTO party_challan_detail VALUES('6', '1', 'Gear', '1504', '6.00', '1', '0', '', 'Expeller', 'PT', '', '');INSERT INTO party_challan_detail VALUES('6', '1', 'Gear', '2685', '3.00', '1', '0', '', 'Expeller', 'PT', '', '');INSERT INTO party_challan_detail VALUES('7', '1', 'Gear', '1504', '6.00', '1', '0', '', 'Expeller', 'PT', '', '');INSERT INTO party_challan_detail VALUES('8', '3', 'Gear', '2981', '0.00', '2', '0', '', 'PowerPress', 'PT', '', '');