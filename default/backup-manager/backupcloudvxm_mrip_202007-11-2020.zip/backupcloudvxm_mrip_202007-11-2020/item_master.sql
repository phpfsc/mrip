 DROP TABLE IF EXISTS `item_master`;

CREATE TABLE `item_master` (
  `cItemCode` varchar(20) NOT NULL,
  `cItemName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO item_master VALUES('Gear', 'Gear');INSERT INTO item_master VALUES('Pinion', 'Pinion');INSERT INTO item_master VALUES('Shaft Pinion', 'Shaft Pinion');INSERT INTO item_master VALUES('Bevel Gear', 'Bevel Gear');INSERT INTO item_master VALUES('Bevel Pinion', 'Bevel Pinion');INSERT INTO item_master VALUES('Chain Wheel', 'Chain Wheel');INSERT INTO item_master VALUES('Worm Gear', 'Worm Gear');