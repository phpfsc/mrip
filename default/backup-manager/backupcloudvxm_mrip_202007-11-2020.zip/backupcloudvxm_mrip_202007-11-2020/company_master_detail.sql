 DROP TABLE IF EXISTS `company_master_detail`;

CREATE TABLE `company_master_detail` (
  `iPartyID` int(11) NOT NULL,
  `iSNo` int(11) NOT NULL,
  `cFirmName` varchar(200) NOT NULL,
  `cFirmTINNO` varchar(100) NOT NULL,
  `cGSTIn` varchar(15) NOT NULL,
  `cHSNCode` varchar(50) NOT NULL,
  `cFirmInvoiceCode` varchar(50) NOT NULL,
  `iFirmInvoiceSerial` int(11) NOT NULL,
  `cFirmPhNo` varchar(100) DEFAULT NULL,
  `cFirmAddress` varchar(200) DEFAULT NULL,
  UNIQUE KEY `cFirmName` (`cFirmName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO company_master_detail VALUES('1', '1', 'God Grace Industries ', '03621050416', '03ABXPG4734B1ZV', '9988', 'GGI', '1165', '0000', '526/8 Old Oswal Street, GT Road Miller Ganj LUDHIANA ');INSERT INTO company_master_detail VALUES('1', '2', 'H.R.A Mechanical Works', '03612043168', '03AAHHA2311K1ZW', '9988', 'HRA', '290', '0000', '518, Nirankari Street No.1 Miller Ganj, LUDHIANA');INSERT INTO company_master_detail VALUES('1', '4', 'Parkash Gears', '03771035347', '03AAYPK0311Q1ZG', '9988', 'PG', '1', '0000', '528,Old Oswal Street,Miller Ganj, LUDHIANA');INSERT INTO company_master_detail VALUES('1', '3', 'Parkash Industrial Corp.', '03481035361', '03AOGPG1701C1ZY', '9988', 'PIC', '516', '0000', '454, Old Oswal Street, Miller Ganj, LUDHIANA');