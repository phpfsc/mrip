 DROP TABLE IF EXISTS `user_rights`;

CREATE TABLE `user_rights` (
  `iUserId` int(11) NOT NULL,
  `cCompanyCode` varchar(20) NOT NULL,
  `iMenuId` int(11) NOT NULL,
  `bView` tinyint(1) NOT NULL,
  `bAdd` tinyint(1) NOT NULL,
  `bUpdate` tinyint(1) NOT NULL,
  `bDelete` tinyint(1) NOT NULL,
  `test` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`test`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO user_rights VALUES('1', 'PG', '1', '1', '1', '1', '1', '1');INSERT INTO user_rights VALUES('1', 'PG', '2', '1', '1', '1', '1', '2');INSERT INTO user_rights VALUES('1', 'PG', '3', '1', '1', '1', '1', '3');INSERT INTO user_rights VALUES('1', 'PG', '4', '1', '1', '1', '1', '4');INSERT INTO user_rights VALUES('1', 'PG', '5', '1', '1', '1', '1', '6');INSERT INTO user_rights VALUES('1', 'PG', '6', '1', '1', '1', '1', '7');INSERT INTO user_rights VALUES('1', 'PG', '8', '1', '1', '1', '1', '8');INSERT INTO user_rights VALUES('1', 'PG', '9', '1', '1', '1', '1', '9');INSERT INTO user_rights VALUES('1', 'PG', '10', '1', '1', '1', '1', '10');INSERT INTO user_rights VALUES('1', 'PG', '11', '1', '1', '1', '1', '11');INSERT INTO user_rights VALUES('1', 'PG', '12', '1', '1', '1', '1', '12');INSERT INTO user_rights VALUES('1', 'PG', '13', '1', '1', '1', '1', '13');INSERT INTO user_rights VALUES('1', 'PG', '14', '1', '1', '1', '1', '14');INSERT INTO user_rights VALUES('1', 'PG', '15', '1', '1', '1', '1', '15');INSERT INTO user_rights VALUES('1', 'PG', '16', '1', '1', '1', '1', '16');INSERT INTO user_rights VALUES('1', 'PG', '17', '1', '1', '1', '1', '17');INSERT INTO user_rights VALUES('1', 'PG', '18', '1', '1', '1', '1', '18');INSERT INTO user_rights VALUES('1', 'PG', '19', '1', '1', '1', '1', '19');INSERT INTO user_rights VALUES('1', 'PG', '20', '1', '1', '1', '1', '20');INSERT INTO user_rights VALUES('1', 'PG', '21', '1', '1', '1', '1', '21');INSERT INTO user_rights VALUES('1', 'PG', '7', '1', '1', '1', '1', '22');INSERT INTO user_rights VALUES('1', 'PG', '22', '1', '1', '1', '1', '23');