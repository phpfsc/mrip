 DROP TABLE IF EXISTS `party_billing`;

CREATE TABLE `party_billing` (
  `iBillingID` int(11) NOT NULL AUTO_INCREMENT,
  `cBillingCode` varchar(100) NOT NULL,
  `dBillingDate` date NOT NULL,
  `dToDate` date NOT NULL,
  `iCompanyCode` int(11) NOT NULL,
  `iCompanySNo` int(11) NOT NULL,
  `iPartyCode` int(11) NOT NULL,
  `iFirmSNo` int(11) NOT NULL,
  `fBillTotal` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'Total Bill Value Without Tax Calculation ( Items Total Amount) Needs to be updated every time Bill is Changed',
  `fVatFactor` int(11) NOT NULL DEFAULT '100',
  `fVatPer` float(10,2) NOT NULL,
  `iCGSTVal` int(11) NOT NULL,
  `iSGSTVal` int(11) NOT NULL,
  `iIGSTVal` int(11) NOT NULL,
  `fSurcharge` float(10,2) DEFAULT '0.00',
  `cMiscTaxName` varchar(100) DEFAULT NULL,
  `fMiscTaxPer` float(10,2) DEFAULT NULL,
  `iBillingType` int(11) NOT NULL DEFAULT '0' COMMENT '0 - Billing Against Order 1- Billing Without Order 2- Burada Billing',
  `fBillAmt` float(10,2) NOT NULL COMMENT 'Bill Amt after calculating Vat Tax and Misc Tax',
  `cRemarks` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`iBillingID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO party_billing VALUES('1', 'PTW/03/11/20-21/001430', '2020-11-03', '2020-11-03', '1', '0', '101', '0', '46.00', '0', '0.00', '0', '0', '10', '0.00', '', '0.00', '2', '51.00', '');INSERT INTO party_billing VALUES('2', 'PTW/04/11/20-21/001431', '2020-11-04', '0000-00-00', '1', '0', '101', '0', '120.00', '0', '0.00', '0', '0', '0', '0.00', '', '0.00', '0', '120.00', '');